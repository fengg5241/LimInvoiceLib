/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
import { Injectable } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * A configuration service for the [`NgbProgressbar`](#/components/progressbar/api#NgbProgressbar) component.
 *
 * You can inject this service, typically in your root component, and customize the values of its properties in
 * order to provide default values for all the progress bars used in the application.
 */
var NgbProgressbarConfig = /** @class */ (function () {
    function NgbProgressbarConfig() {
        this.max = 100;
        this.animated = false;
        this.striped = false;
        this.showValue = false;
    }
    NgbProgressbarConfig.decorators = [
        { type: Injectable, args: [{ providedIn: 'root' },] }
    ];
    /** @nocollapse */ NgbProgressbarConfig.ngInjectableDef = i0.defineInjectable({ factory: function NgbProgressbarConfig_Factory() { return new NgbProgressbarConfig(); }, token: NgbProgressbarConfig, providedIn: "root" });
    return NgbProgressbarConfig;
}());
export { NgbProgressbarConfig };
if (false) {
    /** @type {?} */
    NgbProgressbarConfig.prototype.max;
    /** @type {?} */
    NgbProgressbarConfig.prototype.animated;
    /** @type {?} */
    NgbProgressbarConfig.prototype.striped;
    /** @type {?} */
    NgbProgressbarConfig.prototype.type;
    /** @type {?} */
    NgbProgressbarConfig.prototype.showValue;
    /** @type {?} */
    NgbProgressbarConfig.prototype.height;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJvZ3Jlc3NiYXItY29uZmlnLmpzIiwic291cmNlUm9vdCI6Im5nOi8vQG5nLWJvb3RzdHJhcC9uZy1ib290c3RyYXAvIiwic291cmNlcyI6WyJwcm9ncmVzc2Jhci9wcm9ncmVzc2Jhci1jb25maWcudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7OztBQUFBLE9BQU8sRUFBQyxVQUFVLEVBQUMsTUFBTSxlQUFlLENBQUM7Ozs7Ozs7O0FBUXpDO0lBQUE7UUFFRSxRQUFHLEdBQUcsR0FBRyxDQUFDO1FBQ1YsYUFBUSxHQUFHLEtBQUssQ0FBQztRQUNqQixZQUFPLEdBQUcsS0FBSyxDQUFDO1FBRWhCLGNBQVMsR0FBRyxLQUFLLENBQUM7S0FFbkI7O2dCQVJBLFVBQVUsU0FBQyxFQUFDLFVBQVUsRUFBRSxNQUFNLEVBQUM7OzsrQkFSaEM7Q0FnQkMsQUFSRCxJQVFDO1NBUFksb0JBQW9COzs7SUFDL0IsbUNBQVU7O0lBQ1Ysd0NBQWlCOztJQUNqQix1Q0FBZ0I7O0lBQ2hCLG9DQUFhOztJQUNiLHlDQUFrQjs7SUFDbEIsc0NBQWUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge0luamVjdGFibGV9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG4vKipcbiAqIEEgY29uZmlndXJhdGlvbiBzZXJ2aWNlIGZvciB0aGUgW2BOZ2JQcm9ncmVzc2JhcmBdKCMvY29tcG9uZW50cy9wcm9ncmVzc2Jhci9hcGkjTmdiUHJvZ3Jlc3NiYXIpIGNvbXBvbmVudC5cbiAqXG4gKiBZb3UgY2FuIGluamVjdCB0aGlzIHNlcnZpY2UsIHR5cGljYWxseSBpbiB5b3VyIHJvb3QgY29tcG9uZW50LCBhbmQgY3VzdG9taXplIHRoZSB2YWx1ZXMgb2YgaXRzIHByb3BlcnRpZXMgaW5cbiAqIG9yZGVyIHRvIHByb3ZpZGUgZGVmYXVsdCB2YWx1ZXMgZm9yIGFsbCB0aGUgcHJvZ3Jlc3MgYmFycyB1c2VkIGluIHRoZSBhcHBsaWNhdGlvbi5cbiAqL1xuQEluamVjdGFibGUoe3Byb3ZpZGVkSW46ICdyb290J30pXG5leHBvcnQgY2xhc3MgTmdiUHJvZ3Jlc3NiYXJDb25maWcge1xuICBtYXggPSAxMDA7XG4gIGFuaW1hdGVkID0gZmFsc2U7XG4gIHN0cmlwZWQgPSBmYWxzZTtcbiAgdHlwZTogc3RyaW5nO1xuICBzaG93VmFsdWUgPSBmYWxzZTtcbiAgaGVpZ2h0OiBzdHJpbmc7XG59XG4iXX0=