import { ChartService } from './chart.service';
export declare class ChartModule {
    private cs;
    constructor(cs: ChartService);
}
