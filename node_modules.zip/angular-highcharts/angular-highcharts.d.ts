/**
 * Generated bundle index. Do not edit.
 */
export * from './public_api';
export { ChartDirective as ɵb } from './lib/chart.directive';
export { ChartService as ɵa } from './lib/chart.service';
