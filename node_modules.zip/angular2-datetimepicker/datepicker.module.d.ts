export declare class AngularDateTimePickerModule {
}
